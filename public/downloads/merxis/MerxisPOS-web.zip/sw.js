// Merxis service worker, for the web/PWA build only (the Android APK never registers it).
// The app keeps its data on the device, so all it needs offline is its own files: every
// page and every built asset is cached on install. Each deploy registers this file with a
// new ?v=, which installs a fresh cache and drops the old one once the old tabs are gone.

const VERSION = new URL(self.location.href).searchParams.get("v") || "dev";
const CACHE = `merxis-${VERSION}`;
const FONT_CACHE = "merxis-fonts";

const PAGES = [
  "/",
  "/vender",
  "/almacen",
  "/movimientos",
  "/produccion",
  "/gastos",
  "/reportes",
  "/ajustes",
];
const STATIC = [
  "/manifest.webmanifest",
  "/favicon.svg",
  "/brand/merxis-pos.png",
  "/brand/unchained-business.png",
  "/apple-touch-icon.png",
  "/icon-192.png",
  "/icon-512.png",
  "/icon-maskable-512.png",
  "/fonts/source-sans-3-latin-wght-normal.woff2",
  "/fonts/source-sans-3-latin-wght-italic.woff2",
  "/fonts/fraunces-latin-opsz-normal.woff2",
];
const FONT_HOSTS = ["fonts.googleapis.com", "fonts.gstatic.com"];

// Built files name each other as "/assets/x-hash.js" or "assets/x-hash.js", and a chunk
// loads its lazy neighbours as import("./x-hash.js") (Excel export, barcode reader).
const ASSET_REF = /\/?assets\/[\w.-]+\.(?:js|css|wasm|woff2?|png|svg|jpg|webp)/g;
const SIBLING_REF = /\.\/([\w.-]+\.(?:js|css|wasm))/g;
const scanned = /\.(?:js|css)$/;

self.addEventListener("install", (event) => {
  event.waitUntil(precache());
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keep = new Set([CACHE, FONT_CACHE]);
      for (const key of await caches.keys()) {
        if (key.startsWith("merxis-") && !keep.has(key)) await caches.delete(key);
      }
      await self.clients.claim();
    })(),
  );
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;
  const url = new URL(request.url);

  if (FONT_HOSTS.includes(url.hostname)) {
    event.respondWith(cacheFirst(request, FONT_CACHE));
    return;
  }
  if (url.origin !== self.location.origin) return;

  // The manifest too: the browser checks it to update an installed app's name and icons,
  // and a cached copy would keep showing it the old ones.
  if (request.mode === "navigate" || url.pathname === "/manifest.webmanifest") {
    event.respondWith(page(request, url));
  } else if (url.pathname.startsWith("/assets/") || STATIC.includes(url.pathname)) {
    event.respondWith(cacheFirst(request, CACHE));
  }
});

async function precache() {
  const cache = await caches.open(CACHE);
  await cache.addAll(STATIC);

  const queue = [];
  for (const path of PAGES) {
    const res = await fetch(path, { cache: "no-store" });
    if (!res.ok) continue;
    queue.push({ text: await res.clone().text(), inAssets: false });
    await cache.put(path, res);
  }

  // Follow references from the pages into the bundles, so lazy chunks (Excel export,
  // barcode reader and its wasm) work offline even if they were never opened online.
  const seen = new Set();
  while (queue.length) {
    for (const path of assetRefs(queue.pop())) {
      if (seen.has(path)) continue;
      seen.add(path);
      const res = await fetch(path);
      if (!res.ok) continue;
      if (scanned.test(path)) queue.push({ text: await res.clone().text(), inAssets: true });
      await cache.put(path, res);
    }
  }
}

/** Paths of the built files a page or bundle points to. */
function assetRefs({ text, inAssets }) {
  const paths = (text.match(ASSET_REF) ?? []).map((ref) => (ref.startsWith("/") ? ref : `/${ref}`));
  if (inAssets) for (const [, name] of text.matchAll(SIBLING_REF)) paths.push(`/assets/${name}`);
  return paths;
}

/** Fresh page (or manifest) when online, and keep it for later; the saved copy when offline. */
async function page(request, url) {
  const cache = await caches.open(CACHE);
  try {
    const res = await fetch(request);
    if (res.ok) await cache.put(url.pathname, res.clone());
    return res;
  } catch (error) {
    const saved = (await cache.match(url.pathname)) ?? (await cache.match("/"));
    if (saved) return saved;
    throw error;
  }
}

async function cacheFirst(request, name) {
  const cache = await caches.open(name);
  const saved = await cache.match(request);
  if (saved) return saved;
  const res = await fetch(request);
  if (res.ok || res.type === "opaque") await cache.put(request, res.clone());
  return res;
}
